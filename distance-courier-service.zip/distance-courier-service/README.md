This is a .NET 8 console application for estimating courier delivery cost
and delivery time.

Design focuses on:
- Clean code
- SOLID principles
- Readability
- Easy extension of offers
